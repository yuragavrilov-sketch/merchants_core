# merchants-core test data export

Captured from the TCB test Oracle on 2026-09-18T17:36:47.141130+03:00. The archive contains the three tables consumed by merchants-core:

- `merchants.csv`: 1,187 rows
- `merchant_config.csv`: 36,520 rows
- `terminal_settings.csv`: 15,024 rows
- `merchants-core-test-data.sql`: equivalent INSERT statements

The export is sanitized for repository use. Merchant names, initiators, logins, passwords, account numbers, BIK/INN/KPP, personal values, URLs, terminal identifiers and endpoint fields are deterministic test values or NULL. Parameter names, feature values, limits and validity intervals are retained for behavior and historical configuration tests.

Load the SQL after `src/test/resources/schema.sql` in a test database. The SQL file intentionally does not delete existing rows; use an isolated schema or delete the three target tables before loading.
